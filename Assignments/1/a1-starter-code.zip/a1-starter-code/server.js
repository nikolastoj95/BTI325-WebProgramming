const express = require("express")
const app = express()
const port = process.env.PORT || 8080

const {walkers, dogs, history} = require("./modules/data.js")

// Displays links for testing the endpoints
app.get("/", (req, res) => {
    return res.sendFile(__dirname + "/views/index.html")
})

// Used to view completed walk sessions
app.get("/history", (req, res) => {
    let htmlOutput = `
        <h1>Walk History</h1>
        <ul>
            <li><a href="/">Go Home</a></li>
        </ul>
        <table>
            <tr>
                <th>Session ID</th>
                <th>Walker ID</th>
                <th>Dog ID</th>
                <th>Rating</th>
                <th>Increase Rating</th>
            </tr>
    `
    for (let i = 0; i < history.length; i++) {
        // add a table row for each walk session
        htmlOutput += `
            <tr>
                <td>${history[i].id}</td>
                <td>${history[i].walkerId}</td>
                <td>${history[i].dogId}</td>
                <td>${history[i].rating}</td>
                <td><a href="/ratings/increase/${history[i].id}">Increase Rating</a></td>
            </tr>
        `
    }

    htmlOutput +=`</table>`
    return res.send(htmlOutput)
})

// ----------------------------------------------
// TODO: Create your endpoints here
// ----------------------------------------------


const startServer = () => {
 console.log(`The server is running on http://localhost:${port}`)
 console.log(`Press CTRL + C to exit`)
}

app.listen(port, startServer)
